
from flask import Flask, render_template, request, jsonify
import face_recognition
import base64
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    image_data = data['image']
    email = data['email']
    
    if not email or not image_data:
        return jsonify({'success': False, 'message': 'Məlumat natamamdır.'})

    try:
        header, encoded = image_data.split(",", 1)
        img_bytes = base64.b64decode(encoded)
        with open("temp.png", "wb") as f:
            f.write(img_bytes)

        # Şəkilləri yüklə
        input_image = face_recognition.load_image_file("temp.png")
        student_image_path = f"students/{email}.jpg"
        if not os.path.exists(student_image_path):
            return jsonify({'success': False, 'message': 'İstifadəçi tapılmadı.'})
        known_image = face_recognition.load_image_file(student_image_path)

        # Üz kodlarını çıxar
        input_enc = face_recognition.face_encodings(input_image)
        known_enc = face_recognition.face_encodings(known_image)

        if not input_enc or not known_enc:
            return jsonify({'success': False, 'message': 'Üz tapılmadı.'})

        result = face_recognition.compare_faces([known_enc[0]], input_enc[0])
        return jsonify({'success': result[0], 'message': 'Giriş uğurludur!' if result[0] else 'Üz tanınmadı.'})

    except Exception as e:
        return jsonify({'success': False, 'message': f'Xəta: {str(e)}'})

if __name__ == '__main__':
    app.run(debug=True)
